import React from 'react';

import './logIn.style.scss';

const LogIn = () => (

    <div className="login">
        <h1>YOU R LOGGED IN</h1>
    </div>

);

export default LogIn;
