import logo from './logo.svg';
import './App.css';

import {Switch, Route} from 'react-router-dom';

import LogIn from './pages/Log-In-Page/logIn.component';

import SignInOut from './pages/Sign-In-Page/SignRes.component';

function App() {
  return (
    <div>
        <Switch>
          <Route exact path='/' component={SignInOut} />
          <Route  path='/login' component={LogIn} />
        </Switch>
      </div>
  );
}

export default App;
