const express = require('express'); /* import express */

const app = express(); /* construtor do express  */

const mysql = require('mysql');

const cors = require('cors'); /* serve para poder fazer ligaçao com outras portas */

const jwt = require("jsonwebtoken"); /* permite me a utilizacao dos tokens*/

app.use(cors());
app.use(express.json());

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true })); 
/* permite interpretar o body do resquest */


const db= mysql.createConnection({
        host: 'localhost',
        user: 'root',
        database: 'react' 
});

db.connect();
    /* processo de conexao a db */

app.listen(5000);

app.post('/register', (req, res) => {
    db.query('INSERT INTO users (email,password) VALUES (?,?)',[
        req.body.email,
        req.body.password
    ],(err,result)=>{
            if (err) console.log(err);
            else {
              console.log("USER ADDED INTO THE DATABASE");
              res.status(201).send("USER ADDED");
            }
    })
});

app.post('/login', (req, res)=>{
    db.query('SELECT * FROM `users` WHERE email = ?',[req.body.email],(err,result)=>{
        if (err) console.log(err);
            else {
                if (result[0].password === req.body.password) {
                    const token=jwt.sign(JSON.stringify(result[0]),'root');
                    console.log("User Confirmed");
                    console.log(result[0].email);
                    res.status(200).send({token:token});
                }
                else{console.log('User nao encontrado');}
                
            }
    })
});


/* funcçao que permite verificar a token */
app.get("/isUserAuth", authenticateToken, (req, res) => {
    res.json({
      authenticated: true,
      message: "User is authenticated",
      user: req.user,
    });
  });
  
  // Middleware function to verify if the token is valid
  function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;
    if (authHeader) {
      const token = authHeader.split(" ")[1];
      jwt.verify(token, "root", (err, user) => {
        if (err) {
          return res.status(401).json({ message: "Token is not valid" });
        }
        req.user = user;
        next();
      });
    } else {
      res.status(401).json({ message: "You are not authorized" });
    }
  }
  